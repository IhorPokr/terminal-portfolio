export function About() {
  return (
    <div className="space-y-4 my-2">
      <h2 className="text-xl text-[var(--apple-blue)] font-bold">About Me</h2>
      <p>I build software tha's intuitive, efficient, and scalable—whether it's a web app or a mobile application. </p>
      <p>
      I work across the stack, from frontend interfaces to backend systems, and have experience developing both web and iOS applications. I focus on writing clean, maintainable code and continuously improving performance and user experience. Always exploring new technologies to build better products.
      </p>
      <div className="mt-4">
        <p className="text-[var(--apple-subtle)]">Education:</p>
        <p>A.S. Computer Science - Triton College (2023-2025)</p>
      </div>
    </div>
  )
}
